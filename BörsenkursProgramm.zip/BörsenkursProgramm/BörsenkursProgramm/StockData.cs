﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace BörsenkursProgramm
{
    public class StockData
    {
        public string Information { get; set; }
        public string Symbol { get; set; }
        public string LastRefreshed { get; set; }
        public string OutputSize { get; set; }
        public string TimeZone { get; set; }
        public decimal Open { get; set; }
        public decimal High { get; set; }
        public decimal Low { get; set; }
        public decimal Close { get; set; }
        public long Volume { get; set; }

        public static StockData FromJson(string json)
        {
            var data = JObject.Parse(json);

            var metaData = data["Meta Data"];
            var timeSeries = data["Time Series (Daily)"];
            var latestData = timeSeries[metaData["3. Last Refreshed"].Value<string>()];

            return new StockData
            {
                Information = metaData["1. Information"].Value<string>(),
                Symbol = metaData["2. Symbol"].Value<string>(),
                LastRefreshed = metaData["3. Last Refreshed"].Value<string>(),
                OutputSize = metaData["4. Output Size"].Value<string>(),
                TimeZone = metaData["5. Time Zone"].Value<string>(),
                Open = latestData["1. open"].Value<decimal>(),
                High = latestData["2. high"].Value<decimal>(),
                Low = latestData["3. low"].Value<decimal>(),
                Close = latestData["4. close"].Value<decimal>(),
                Volume = latestData["5. volume"].Value<long>()
            };
        }
    }

}
