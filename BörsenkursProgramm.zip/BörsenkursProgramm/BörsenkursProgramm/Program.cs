﻿using BörsenkursProgramm;

namespace BörsenkurseProgramm
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // Erstellen Sie einen HttpClient-Objekt
            var client = new HttpClient();

            // Fragen Sie den Benutzer nach dem Aktiensymbol
            Console.WriteLine("Um die gewünschte Aktie anzeigen zu lassen muss ein Symbol der jeweiligen Aktie ausgewählt werden. Beispiel (Tesla = TSLA)");
            Console.WriteLine("Bitte geben Sie das Aktiensymbol ein: ");
            string symbol = Console.ReadLine();

            // Definieren Sie die URL der API, die Sie aufrufen möchten
            var url = $"https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={symbol}&outputsize=compact&apikey=RZTB0Y587CD8VEAZ";

            // Erstellen Sie eine HttpRequestMessage-Objekt mit der GET-Methode
            var request = new HttpRequestMessage(HttpMethod.Get, url);

            // Fügen Sie den access key als Header in der Anfrage hinzu
            request.Headers.Add("x-api-key", "RZTB0Y587CD8VEAZ  ");

            // Senden Sie die Anfrage an die API und erhalten Sie eine Antwort
            var response = await client.SendAsync(request);

            // Überprüfen Sie, ob die Anfrage erfolgreich war
            if (response.IsSuccessStatusCode)
            {
                // Lesen Sie den Inhalt der Antwort als String
                var content = await response.Content.ReadAsStringAsync();

               
                
                 

                    // Erstellen Sie ein StockData-Objekt aus dem JSON-Inhalt
                    var stockData = StockData.FromJson(content);

                    // Jetzt können Sie die Eigenschaften des StockData-Objekts in Ihrem Code verwenden
                    Console.WriteLine($"Symbol: {stockData.Symbol}");
                    Console.WriteLine($"Datum: {stockData.LastRefreshed}");
                    Console.WriteLine($"Eröffnungskurs: {stockData.Open}");
                    Console.WriteLine($"Höchstkurs: {stockData.High}");
                    Console.WriteLine($"Tiefstkurs: {stockData.Low}");
                    Console.WriteLine($"Schlusskurs: {stockData.Close}");
                    Console.WriteLine($"Volumen: {stockData.Volume}");
                
            }
            else
            {
                // Geben Sie den Statuscode und die Fehlermeldung aus
                Console.WriteLine($"Anfrage fehlgeschlagen: {response.StatusCode} - {response.ReasonPhrase}");
            }
        }
    }
}